package main;

public class Enigma 
{
	protected int executions;
	protected int 
}
