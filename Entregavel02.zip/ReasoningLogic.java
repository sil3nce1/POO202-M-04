package main;

public class ReasoningLogic extends Enigma {
	
	
	public ReasoningLogic(int executions, int wrongAnswers, int activations, EnigmaLevel level)
	{
		super(executions, wrongAnswers, activations, level);
	}
	
	public ReasoningLogic() {}
	
	public JPanel 
}
