package main;

import java.util.Timer;
import java.util.TimerTask;

public class Cronometro 
{
	private static Timer timer;
	private static double time;
	
	public Cronometro(double startTime)
	{
		timer = new Timer();
		timer.schedule(new RemindTask(), 1000);
		time = startTime;
	}
	
	class RemindTask extends TimerTask {
        public void run() {
            Cronometro.time += 1;
            
        }
        
    public 
	
	public void stop()
	{
		timer.cancel();
	}
	
	
}
