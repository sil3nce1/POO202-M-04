package main;

public class Bomb implements BombInterface
{
	private Boolean defused;
	private String error;
	private Cronometro cronometro;
	
	
	public Bomb() {
		this.cronometro = new Cronometro(0);
	}
	
	
	public String getError()
	{
		return this.error;
	}
	
	public void setError(String error)
	{
		this.error = error;
	}
	
	public Boolean isDefused()
	{
		return this.defused;
	}
	
	public void setDefused(Boolean defused)
	{
		this.defused = defused;
	}
	
	public Cronometro getCronometro()
	{
		this.cronometro = new Cronometro();
		return this.cronometro.instance;
	}
	
}
