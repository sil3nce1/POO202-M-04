package main;

public interface BombInterface {

}
