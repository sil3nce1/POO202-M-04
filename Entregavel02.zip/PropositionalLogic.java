package main;

public class PropositionalLogic {

}
