package main;

public interface ModuleInterface {

}
