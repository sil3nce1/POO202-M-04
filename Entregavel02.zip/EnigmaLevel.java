package main;
package 
public enum EnigmaLevel {
	HARD, 
	MEDIUM, 
	EASY;
}
